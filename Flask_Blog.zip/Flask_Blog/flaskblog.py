# Basic app
from flask import Flask, render_template, url_for, flash, redirect
from forms import RegistrationForm, LoginForm
app = Flask(__name__, template_folder='Template')

app.config['SECRET_KEY']='dd2fdaee5a65581f6d25c5cda70bcfad'

posts = [
    {
        'author': 'Sherlock Holmes',
        'title': 'Blog Post 1',
        'content': 'First post content',
        'date_posted': 'September 20, 2023'
    },
    {
        'author': 'Dr. John Watson',
        'title': 'Blog Post 2',
        'content': 'Second post content',
        'date_posted': 'September 21, 2023'
    }
]

@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html', posts = posts)

@app.route("/about")
def about():
    return render_template('about.html', title = 'About Page')

@app.route("/register", methods=['GET', 'POST'])
def register():
    reg_form = RegistrationForm()
    if reg_form.validate_on_submit():
        flash(f'Account created for {reg_form.username.data}!', 'success')
        return redirect(url_for('home'))
    return render_template('registration.html', title='Register', form=reg_form)

@app.route("/login", methods=['GET', 'POST'])
def login():
    log_form = LoginForm()
    return render_template('login.html', title='Login', form=log_form)


if __name__ == '__main__':
  app.run(debug=True)